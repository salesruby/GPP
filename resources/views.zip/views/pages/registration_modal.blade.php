@extends('layouts.modal')
@section('modal-id')
registration_modal
@overwrite

@section('modal-title')
Sign up to GGP
@overwrite

@section('modal-content')
    Sign up to GGP
@overwrite


@section('modal-footer')
    Test
@overwrite
