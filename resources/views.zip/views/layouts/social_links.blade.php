<div  class="social_links">
    <ul>
        <li class="hidden-xs">
            <a href="https://web.facebook.com/globalpluspub" title="Facebook">
                <img src="{{asset('template/images/mail/facebook.svg')}}" alt="Facebook">
                <!-- Connect with facebook -->
            </a>
        </li>
        <li class="hidden-xs">
            <a href="https://twitter.com/GlobalPlusPub" title="Twitter">
                <img src="{{asset('template/images/mail/twitter.svg')}}" alt="twitter">
            </a>
        </li>
        <li class="hidden-xs">
            <a href="https://www.instagram.com/globalpluspub/" title="Instagram">
                <img src="{{asset('template/images/mail/instagram.svg')}}" alt="Instagram">
            </a>
        </li>
        <li class="hidden-xs">
            <a href="https://www.linkedin.com/company/global-plus-publishing" title="Linkedin">
                <img src="{{asset('template/images/mail/linkedin.svg')}}" alt="Linkedin">
            </a>
        </li>
    </ul>
</div>
