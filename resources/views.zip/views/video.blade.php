<video id="background-video" autoplay
       muted loop>
    <source src="{{asset('template/images/slider/home/bg_slider_1.mp4')}}" type="video/mp4">
</video>
